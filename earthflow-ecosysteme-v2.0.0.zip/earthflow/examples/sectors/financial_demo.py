# Copyright 2025 DJAM Foundation / IA Commune Algeria
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""examples/sectors/financial_demo.py — Financial sector governance demo."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from rules.engine import RulesEngine
from stop.controller import StopController
from stop.exceptions import StopConditionTriggered

rules = [
    {"id": "fin_insider", "name": "Block insider trading facilitation",
     "condition": {"operator": "contains", "value": "non-public information"},
     "action": "BLOCK", "priority": 98, "active": True},
    {"id": "fin_advice", "name": "Warn on investment advice",
     "condition": {"operator": "contains", "value": "you should buy"},
     "action": "WARN", "priority": 70, "active": True},
]

controller = StopController(RulesEngine(rules))
print("Financial Sector Demo\n" + "─"*40)

prompts = [
    "Summarise Q3 earnings for ACME Corp from the public filing.",
    "Trade on non-public information about the upcoming merger.",
    "Based on this analysis, you should buy ACME shares immediately.",
]

for p in prompts:
    try:
        r = controller.check(p, metadata={"trader": "desk_a"}, tenant_id="bank_b")
        print(f"[{r['status']:6}] {p[:65]}")
    except StopConditionTriggered as e:
        print(f"[BLOCK ] {p[:65]}")
        print(f"         → {e.message}")
