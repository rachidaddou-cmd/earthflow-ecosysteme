---
name: Feature Request
about: Propose a new capability or improvement for Earthflow Écosystème
title: "[FEAT] <short description>"
labels: enhancement, needs-triage
assignees: ''
---

## Summary

<!-- One paragraph describing the feature and the problem it solves. -->

## Problem / Motivation

<!-- What pain point, compliance gap, or use case drives this request?
     Be specific: "When I do X, I cannot Y because Z." -->

## Proposed Solution

<!-- Describe your preferred solution. Include API changes, new config fields,
     UI changes, or rule operators if relevant. -->

## Alternatives Considered

<!-- What other approaches did you evaluate and why did you reject them? -->

## Use Case

**Sector:** <!-- medical / financial / HR / generic -->  
**User role:** <!-- platform admin / tenant admin / developer / end user -->

```
# Concrete example of how the feature would be used:
# e.g. new rule operator, new API endpoint, new SDK method
```

## Acceptance Criteria

- [ ] 
- [ ] 
- [ ] 

## Regulatory / Compliance Relevance

<!-- Does this feature help address a specific regulation?
     e.g. EU AI Act Art. 13, GDPR Art. 22, HIPAA, MiFID II -->

| Regulation | Article | Relevance |
|---|---|---|
| | | |

## Priority Justification

- [ ] Blocking a production deployment
- [ ] Required for regulatory compliance
- [ ] Significant developer experience improvement
- [ ] Nice to have

## Additional Context

<!-- Mockups, related issues, external references, links to standards, etc. -->
