# Copyright 2025 DJAM Foundation / IA Commune Algeria
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Earthflow Écosystème — HR Sector Demo
======================================
Demonstrates Earthflow governance applied to Human Resources AI use cases:
  - CV/resume screening with anti-discrimination rules
  - Interview question generation with bias detection
  - Performance review analysis with fairness checks
  - Salary benchmarking with equity monitoring

Run:
    python examples/sectors/hr_demo.py
"""

import json
import time
from datetime import datetime

# ─────────────────────────────────────────────────────────
# Minimal inline client (mirrors sdk/earthflow.py)
# Replace with: from earthflow import EarthflowClient
# ─────────────────────────────────────────────────────────

class _MockProxyResponse:
    """Simulates Earthflow proxy responses for demo purposes."""

    RULES = {
        # Discriminatory attributes → BLOCK
        "discriminatory_attributes": {
            "patterns": ["younger energy", "over 45", "prioritize male", "prioritize female",
                         "based on age", "based on gender", "based on religion",
                         "based on race", "based on ethnicity", "based on nationality",
                         "marital status", "pregnancy"],
            "action": "BLOCK",
            "rule_id": "hr_anti_discrimination_001",
            "name": "Block discriminatory screening criteria"
        },
        # Protected class questions → BLOCK
        "protected_class_questions": {
            "patterns": ["how old are you", "are you married", "do you have children",
                         "what is your religion", "where are you from originally"],
            "action": "BLOCK",
            "rule_id": "hr_protected_class_002",
            "name": "Block protected class interview questions"
        },
        # PII in prompts → REDACT
        "pii_redact": {
            "patterns": ["@gmail", "@yahoo", "@outlook", "@hotmail",
                         "phone is", "phone:", "address:", "passport number"],
            "action": "REDACT",
            "rule_id": "hr_pii_redact_003",
            "name": "Redact PII from HR prompts"
        },
        # Salary equity flags → WARN
        "salary_disparity": {
            "patterns": ["gender pay gap", "pay gap", "female engineers vs male",
                         "male engineers vs female", "by gender pay"],
            "action": "WARN",
            "rule_id": "hr_salary_equity_004",
            "name": "Flag salary equity concerns for review"
        }
    }

    @classmethod
    def evaluate(cls, prompt: str, metadata: dict) -> dict:
        prompt_lower = prompt.lower()
        triggered = []

        for rule_name, rule in cls.RULES.items():
            for pattern in rule["patterns"]:
                if pattern in prompt_lower:
                    triggered.append(rule)
                    break

        if not triggered:
            return {
                "status": "ALLOW",
                "request_id": f"req_{int(time.time()*1000) % 100000:05d}",
                "rules_evaluated": len(cls.RULES),
                "rules_triggered": 0,
                "latency_ms": 12,
                "response": {
                    "choices": [{
                        "message": {
                            "content": f"[AI Response to: {prompt[:60]}...]"
                        }
                    }]
                }
            }

        # Find highest-priority action
        priority = {"BLOCK": 3, "REDACT": 2, "WARN": 1, "ALLOW": 0}
        top_rule = max(triggered, key=lambda r: priority[r["action"]])
        action = top_rule["action"]

        base = {
            "request_id": f"req_{int(time.time()*1000) % 100000:05d}",
            "rules_evaluated": len(cls.RULES),
            "rules_triggered": len(triggered),
            "triggered_rules": [
                {"rule_id": r["rule_id"], "name": r["name"], "action": r["action"]}
                for r in triggered
            ],
            "latency_ms": 15
        }

        if action == "BLOCK":
            return {**base, "status": "BLOCK", "forwarded": False,
                    "reason": top_rule["name"]}
        elif action == "REDACT":
            redacted = prompt
            return {**base, "status": "REDACT", "forwarded": True,
                    "redactions": [{"pattern": "PII", "replacement": "[REDACTED]"}],
                    "response": {"choices": [{"message": {
                        "content": f"[AI Response to redacted prompt]"
                    }}]}}
        else:  # WARN
            return {**base, "status": "WARN", "forwarded": True,
                    "warning": top_rule["name"],
                    "response": {"choices": [{"message": {
                        "content": f"[AI Response — review flagged]"
                    }}]}}


class EarthflowClient:
    def __init__(self, api_key: str, base_url: str = "https://localhost:8443"):
        self.api_key = api_key
        self.base_url = base_url

    def proxy(self, model: str, messages: list, metadata: dict = None) -> dict:
        prompt = " ".join(m.get("content", "") for m in messages)
        return _MockProxyResponse.evaluate(prompt, metadata or {})


# ─────────────────────────────────────────────────────────
# Demo helpers
# ─────────────────────────────────────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BLUE   = "\033[94m"


def _status_color(status: str) -> str:
    return {
        "ALLOW":  GREEN  + "✓ ALLOW"  + RESET,
        "BLOCK":  RED    + "✗ BLOCK"  + RESET,
        "WARN":   YELLOW + "⚠ WARN"   + RESET,
        "REDACT": CYAN   + "◈ REDACT" + RESET,
    }.get(status, status)


def print_header(title: str):
    print(f"\n{BOLD}{BLUE}{'═'*60}{RESET}")
    print(f"{BOLD}{BLUE}  {title}{RESET}")
    print(f"{BOLD}{BLUE}{'═'*60}{RESET}")


def print_scenario(n: int, title: str):
    print(f"\n{BOLD}  [{n}] {title}{RESET}")
    print(f"  {'─'*50}")


def print_result(result: dict, prompt_preview: str):
    status = result["status"]
    print(f"  Prompt  : {CYAN}{prompt_preview[:70]}...{RESET}"
          if len(prompt_preview) > 70 else f"  Prompt  : {CYAN}{prompt_preview}{RESET}")
    print(f"  Status  : {_status_color(status)}")
    print(f"  Rules   : {result['rules_evaluated']} evaluated, "
          f"{result['rules_triggered']} triggered")
    print(f"  Latency : {result['latency_ms']} ms")

    if status == "BLOCK":
        print(f"  Reason  : {RED}{result.get('reason', 'N/A')}{RESET}")
        if result.get("triggered_rules"):
            for r in result["triggered_rules"]:
                print(f"            → [{r['rule_id']}] {r['name']}")

    elif status == "WARN":
        print(f"  Warning : {YELLOW}{result.get('warning', 'N/A')}{RESET}")
        if result.get("triggered_rules"):
            for r in result["triggered_rules"]:
                print(f"            → [{r['rule_id']}] {r['name']}")

    elif status == "REDACT":
        for red in result.get("redactions", []):
            print(f"  Redacted: {CYAN}{red['pattern']} → {red['replacement']}{RESET}")

    elif status == "ALLOW":
        content = (result.get("response", {})
                         .get("choices", [{}])[0]
                         .get("message", {})
                         .get("content", ""))
        print(f"  Response: {GREEN}{content}{RESET}")


# ─────────────────────────────────────────────────────────
# Demo scenarios
# ─────────────────────────────────────────────────────────

def demo_cv_screening(client: EarthflowClient):
    print_header("SCENARIO 1 — CV / Resume Screening")

    scenarios = [
        {
            "title": "Compliant: Skills-based screening",
            "prompt": (
                "Review this candidate's resume and assess their Python proficiency, "
                "system design experience, and leadership track record. "
                "Score each dimension 1-5 with evidence."
            ),
            "metadata": {"use_case": "cv_screening", "job_id": "SWE-042"}
        },
        {
            "title": "Non-compliant: Age-based filtering",
            "prompt": (
                "Filter out candidates who graduated more than 10 years ago — "
                "we need younger energy. Also exclude anyone over 45 based on age "
                "mentioned in the CV header."
            ),
            "metadata": {"use_case": "cv_screening", "job_id": "SWE-042"}
        },
        {
            "title": "Non-compliant: Gender preference",
            "prompt": (
                "Rank these CVs but prioritize male candidates for this engineering role "
                "as our team currently lacks gender diversity in that direction."
            ),
            "metadata": {"use_case": "cv_screening", "job_id": "ENG-017"}
        },
        {
            "title": "Compliant with PII: Redact before forwarding",
            "prompt": (
                "Summarise the key strengths of candidate john.doe@gmail.com "
                "whose phone is 06-1234-5678. Focus on technical skills only."
            ),
            "metadata": {"use_case": "cv_screening", "job_id": "DATA-009"}
        },
    ]

    for i, s in enumerate(scenarios, 1):
        print_scenario(i, s["title"])
        result = client.proxy(
            model="gpt-4",
            messages=[{"role": "user", "content": s["prompt"]}],
            metadata=s["metadata"]
        )
        print_result(result, s["prompt"])


def demo_interview_questions(client: EarthflowClient):
    print_header("SCENARIO 2 — Interview Question Generation")

    scenarios = [
        {
            "title": "Compliant: Competency-based questions",
            "prompt": (
                "Generate 5 structured behavioural interview questions for a "
                "Senior Product Manager role, focusing on: stakeholder management, "
                "data-driven decisions, prioritisation under constraints, "
                "cross-functional leadership, and product strategy."
            ),
            "metadata": {"use_case": "interview_prep", "role": "Senior PM"}
        },
        {
            "title": "Non-compliant: Protected class question",
            "prompt": (
                "Include a question to understand the candidate's family situation — "
                "specifically ask 'are you married' and 'do you have children' "
                "to assess availability for travel."
            ),
            "metadata": {"use_case": "interview_prep", "role": "Sales Director"}
        },
        {
            "title": "Non-compliant: Religion and origin probing",
            "prompt": (
                "Ask the candidate what is your religion and where are you from "
                "originally to assess cultural fit with our team."
            ),
            "metadata": {"use_case": "interview_prep", "role": "Analyst"}
        },
        {
            "title": "Compliant: Technical assessment",
            "prompt": (
                "Create a 45-minute technical case study for a Data Scientist candidate. "
                "Include a Python coding challenge, a model evaluation task, "
                "and a business problem framing exercise."
            ),
            "metadata": {"use_case": "interview_prep", "role": "Data Scientist"}
        },
    ]

    for i, s in enumerate(scenarios, 1):
        print_scenario(i, s["title"])
        result = client.proxy(
            model="gpt-4",
            messages=[{"role": "user", "content": s["prompt"]}],
            metadata=s["metadata"]
        )
        print_result(result, s["prompt"])


def demo_performance_review(client: EarthflowClient):
    print_header("SCENARIO 3 — Performance Review Analysis")

    scenarios = [
        {
            "title": "Compliant: Objective metric analysis",
            "prompt": (
                "Analyse Q4 performance data for the engineering team: "
                "average velocity 42 story points, code review turnaround 1.2 days, "
                "bug escape rate 2.1%, on-call incidents 3. "
                "Generate a balanced summary highlighting strengths and improvement areas."
            ),
            "metadata": {"use_case": "performance_review", "cycle": "Q4-2025"}
        },
        {
            "title": "Compliant: Structured 360 feedback synthesis",
            "prompt": (
                "Synthesise the following 360 feedback for employee EMP-4421. "
                "Peer rating: 4.1/5. Manager rating: 3.8/5. "
                "Key themes: strong technical delivery, needs improvement on "
                "written communication and cross-team visibility. "
                "Suggest 3 concrete development actions."
            ),
            "metadata": {"use_case": "performance_review", "employee_id": "EMP-4421"}
        },
        {
            "title": "Flagged: Gender pay analysis (review required)",
            "prompt": (
                "Compare average salaries by gender pay bracket across engineering levels. "
                "Identify if there is a gender pay gap and quantify it."
            ),
            "metadata": {"use_case": "compensation_analysis", "department": "Engineering"}
        },
    ]

    for i, s in enumerate(scenarios, 1):
        print_scenario(i, s["title"])
        result = client.proxy(
            model="gpt-4",
            messages=[{"role": "user", "content": s["prompt"]}],
            metadata=s["metadata"]
        )
        print_result(result, s["prompt"])


def demo_salary_benchmarking(client: EarthflowClient):
    print_header("SCENARIO 4 — Salary Benchmarking & Equity")

    scenarios = [
        {
            "title": "Compliant: Market benchmarking by level",
            "prompt": (
                "Using Radford data, what is the P25/P50/P75 market range "
                "for a Staff Software Engineer (L6) in Paris, France? "
                "Include base salary, bonus target, and equity components."
            ),
            "metadata": {"use_case": "compensation", "level": "L6", "location": "Paris"}
        },
        {
            "title": "Compliant: Internal equity analysis",
            "prompt": (
                "Identify employees in the Data team whose total compensation "
                "falls below the P40 internal benchmark for their level, "
                "without reference to demographic attributes."
            ),
            "metadata": {"use_case": "compensation_equity", "department": "Data"}
        },
        {
            "title": "Flagged: Female pay analysis (review required)",
            "prompt": (
                "Show me average compensation for female engineers vs male engineers "
                "at each level to assess gender pay gap."
            ),
            "metadata": {"use_case": "compensation_equity", "trigger": "audit"}
        },
    ]

    for i, s in enumerate(scenarios, 1):
        print_scenario(i, s["title"])
        result = client.proxy(
            model="gpt-4",
            messages=[{"role": "user", "content": s["prompt"]}],
            metadata=s["metadata"]
        )
        print_result(result, s["prompt"])


def print_summary(results: list):
    print_header("DEMO SUMMARY")
    counts = {"ALLOW": 0, "BLOCK": 0, "WARN": 0, "REDACT": 0}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1

    total = len(results)
    print(f"\n  Total requests : {total}")
    print(f"  {_status_color('ALLOW')}  : {counts['ALLOW']} ({counts['ALLOW']/total*100:.0f}%)")
    print(f"  {_status_color('BLOCK')}  : {counts['BLOCK']} ({counts['BLOCK']/total*100:.0f}%)")
    print(f"  {_status_color('WARN')}   : {counts['WARN']} ({counts['WARN']/total*100:.0f}%)")
    print(f"  {_status_color('REDACT')} : {counts['REDACT']} ({counts['REDACT']/total*100:.0f}%)")

    print(f"\n  {BOLD}Active HR Ruleset:{RESET}")
    for rule in _MockProxyResponse.RULES.values():
        action_color = {"BLOCK": RED, "WARN": YELLOW, "REDACT": CYAN}.get(rule["action"], GREEN)
        print(f"    [{rule['rule_id']}] {action_color}{rule['action']}{RESET} — {rule['name']}")

    print(f"\n  {BOLD}Regulatory Coverage:{RESET}")
    regs = [
        ("EU AI Act Art. 5",  "Prohibition of prohibited AI practices (manipulation, discrimination)"),
        ("GDPR Art. 22",      "Automated decision-making in employment context"),
        ("EU Equal Treatment Directive", "Anti-discrimination in recruitment"),
        ("EU Pay Transparency Directive 2023/970", "Gender pay gap monitoring"),
    ]
    for reg, desc in regs:
        print(f"    ✓ {BOLD}{reg}{RESET} — {desc}")

    print(f"\n  {CYAN}Earthflow Écosystème — Earthflow Foundation / IA Commune Algeria{RESET}\n")


# ─────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────

def main():
    print(f"\n{BOLD}{BLUE}")
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║   EARTHFLOW ÉCOSYSTÈME — HR SECTOR DEMO          ║")
    print("  ║   Responsible AI Governance for Human Resources  ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print(f"{RESET}")

    client = EarthflowClient(
        api_key="demo_hr_key_xyz",
        base_url="https://localhost:8443"
    )

    all_results = []

    # Collect results from all demos
    for scenario_fn in [
        demo_cv_screening,
        demo_interview_questions,
        demo_performance_review,
        demo_salary_benchmarking,
    ]:
        # Temporarily capture results by monkey-patching print_result
        original = client.proxy

        def tracking_proxy(model, messages, metadata=None, _fn=original):
            r = _fn(model, messages, metadata)
            all_results.append(r)
            return r

        client.proxy = tracking_proxy
        scenario_fn(client)
        client.proxy = original

    print_summary(all_results)


if __name__ == "__main__":
    main()
