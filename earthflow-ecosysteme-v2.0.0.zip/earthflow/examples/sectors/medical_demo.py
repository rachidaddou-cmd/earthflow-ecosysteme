# Copyright 2025 DJAM Foundation / IA Commune Algeria
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""examples/sectors/medical_demo.py — Medical sector governance demo."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from rules.engine import RulesEngine
from stop.controller import StopController
from stop.exceptions import StopConditionTriggered

rules = [
    {"id": "med_prescribe", "name": "Block prescription generation",
     "condition": {"operator": "contains", "value": "prescribe"},
     "action": "BLOCK", "priority": 95, "active": True},
    {"id": "med_pii", "name": "Redact SSN",
     "condition": {"operator": "regex", "value": r"\d{3}-\d{2}-\d{4}"},
     "action": "REDACT", "priority": 80, "active": True},
]

controller = StopController(RulesEngine(rules))
print("Medical Sector Demo\n" + "─"*40)

prompts = [
    "Summarise the patient's vital signs from the attached report.",
    "Prescribe 500mg amoxicillin for the patient.",
    "Patient record: John Doe, SSN 123-45-6789, diagnosis pending.",
]

for p in prompts:
    try:
        r = controller.check(p, metadata={"dept": "cardiology"}, tenant_id="hospital_a")
        print(f"[{r['status']:6}] {p[:60]}")
    except StopConditionTriggered as e:
        print(f"[BLOCK ] {p[:60]}")
        print(f"         → {e.message}")
