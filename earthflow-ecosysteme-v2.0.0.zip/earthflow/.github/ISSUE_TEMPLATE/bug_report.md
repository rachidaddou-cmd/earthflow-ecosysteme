---
name: Bug Report
about: Report a defect or unexpected behaviour in Earthflow Écosystème
title: "[BUG] <short description>"
labels: bug, needs-triage
assignees: ''
---

## Summary

<!-- One or two sentences describing what is broken. -->

## Environment

| Field | Value |
|---|---|
| Earthflow version | <!-- e.g. 2.0.0 --> |
| Deployment type | <!-- Docker / Kubernetes / bare-metal --> |
| OS / distro | <!-- e.g. Ubuntu 24.04 --> |
| Python version | <!-- e.g. 3.12.2 --> |
| Component affected | <!-- proxy / rules engine / dashboard / webhook / rate limiter / anonymizer / other --> |

## Steps to Reproduce

1. 
2. 
3. 

## Expected Behaviour

<!-- What should happen. -->

## Actual Behaviour

<!-- What actually happens. Include error messages verbatim. -->

## Logs / Stack Trace

```
# Paste relevant logs here. Remove any sensitive data before posting.
# Obtain with: docker compose logs earthflow-proxy --tail=100
```

## Minimal Reproducible Example

```python
# If applicable, paste the smallest code snippet that triggers the bug.
```

## Impact

- [ ] Service unavailable / total failure
- [ ] Incorrect rule evaluation (ALLOW when should BLOCK, or vice versa)
- [ ] Data leak / PII exposed
- [ ] Performance degradation
- [ ] Cosmetic / minor

## Additional Context

<!-- Screenshots, related issues, workarounds you have found, etc. -->

---

> **Security vulnerability?** Do **not** open a public issue.  
> Follow the responsible disclosure process in [SECURITY.md](../../SECURITY.md).
